/*
Name: Evan Clemens
Date: 04/12/2021
Description: This code outlines an "iVend" vending machine that can dispense Reeses, Twix, and Snickers. 
It does this by having the user insert cents, make a selection, and then finally make a purchase and receive their treat.
It also gives the user back their unspent cents they inserted, and keeps track of total profits.
Sources Cited: NA
*/

package Vending;

public class VendingMachine implements VendingMachineInterface { // We implement VendingMachineInterface here so we can use that interfaces previously outlined classes 

	private int snickers,twix,reeses,cents,change,selection,profit; // Here i define all the ints needed for the vending machine project 
	
	public VendingMachine(int s, int t, int r) { // This public class defines the treats a user can pick from and how much are in the iVend machine
		snickers = s;
		twix = t;
		reeses = r;
		selection = 3; 	
	}
	public void insertCents(int c) { // Here, this class lets the user insert their desired amount of cents, and if it is not divisible by 5, an error is thrown
		if(c % 5 != 0)
			throw new ImproperCoinsException();
		else // If the if statement is not triggered, the input passes and cents is set equal to "c"
			cents = c;
	}
	public void makeSelection(int s) { // This class does a similar task to "insertCents" as it checks to see if the user has made a valid selection of either 0(snickers),1(txix), or 2(reeses)
		if(s > 2 || s < 0) // If the users selection does not fall into the previously described range, an error is thrown
			throw new ImproperSelectionException();
		else
			selection = s; // If the if statement is not triggered, the input passes and selection is set equal to "s"
		if(selection == 0 && snickers == 0) // Each of the following if statements checks to see if the treat the user selected is in stock, and if not, an error is thrown 
		{
			selection = 3;
			throw new ImproperSelectionException("snickers");
		}
		if(selection == 1 && twix == 0) 
		{
			selection = 3;
			throw new ImproperSelectionException("twix");
		}
		if(selection == 2 && reeses == 0) 
		{
			selection = 3;
			throw new ImproperSelectionException("reeses");
		}
	}
	public int purchaseSelection() { // This class defines the procedure for finally purchasing a treat
		if(selection == 0) // These next 3 if statements define what should happen if a treat is selected and the correct funds have been deposited by the user 
			if(cents >= 100)
			{
				snickers --; // Shows that one snickers has been removed from the machine 
				change = cents - 100; // Tells the user how much change they have after their selection
				profit = profit + 100; // Adds the amount from the snickers purchase to the machines total profits acquired 
			}
			else
				throw new ImproperPurchaseException(100 - cents); // An error is thrown is the user does not have enough cents in the machine to purchase the treat they want 
		if(selection == 1) // The same goes here for the previously described loop, expect this is for twix
			if(cents >= 115)
			{
				twix --;
				change = cents - 115;
				profit = profit + 115; 
			}
			else
				throw new ImproperPurchaseException(115 - cents); 
		if(selection == 2) // The same goes here for the previously described loop, expect this is for reeses
			if(cents >= 130)
			{
				reeses --;
				change = cents - 130;
				profit = profit + 130; 
			}
			else
				throw new ImproperPurchaseException(130 - cents);
		if(selection == 3) // If the user selects "3" as their option, an error is thrown because this is not a valid number to select 
			throw new ImproperPurchaseException();
		return change;
	}
	public int returnUnspentCents() { // Returns the users unspent cents that they inserted into the machine 
		return cents;
	}
	public int getProfits() { // Gets the total profits that the machine has made 
		return profit;
	}
	
}