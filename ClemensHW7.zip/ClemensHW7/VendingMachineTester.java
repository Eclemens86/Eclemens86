package Vending;

import org.junit.Test;
import static org.junit.Assert.*;

public class VendingMachineTester { // This class runs 8 JUint tests to assure that everything is working smoothly with our vending machine and that the proper errors are thrown at correct incidents
	@Test(expected = ImproperCoinsException.class) // The first test sees a user input a value of cents not divisible by 5, so an error should be thrown 
	public void insertCoinsTest() {
		VendingMachine iVend = new VendingMachine(10,10,10);
		iVend.insertCents(3);
	}
	@Test(expected = ImproperSelectionException.class) // The second test sees a user select number 3 and that is out of the possible range for selection, so an error should be thrown 
	public void makeSelectionTest() {
		VendingMachine iVend = new VendingMachine(10,10,10);
		iVend.makeSelection(3);
	}
	@Test(expected = ImproperSelectionException.class) // The third test sees a user select a correct number value but that treat is out, so an error should be thrown 
	public void makeSelectionTest2() {
		VendingMachine iVend = new VendingMachine(0,10,10);
		iVend.makeSelection(0);
	}
	@Test(expected = ImproperPurchaseException.class) // The fourth test sees a user try to make a purchase without first selecting a treat, so an error should be thrown 
	public void makePurchaseTest() {
		VendingMachine iVend = new VendingMachine(10,10,10);
		iVend.purchaseSelection();
	}
	@Test(expected = ImproperPurchaseException.class) // The fifth test sees a user insert an acceptable cent amount, but it is not enough for their desired treat, so an error should be thrown 
	public void makePurchaseTest2() {
		VendingMachine iVend = new VendingMachine(10,10,10);
		iVend.insertCents(20);
		iVend.makeSelection(0);
		iVend.purchaseSelection();

	}
	@Test() // The sixth test sees a user insert an acceptable coin amount and also make a an acceptable selection, so we are checking that the correct amount of change is given back to the user
	public void returnCentsTest() {
		VendingMachine iVend = new VendingMachine(10,10,10);
		iVend.insertCents(105);
		iVend.makeSelection(0);
		assertEquals(iVend.purchaseSelection(),5);
	}
	@Test()
	public void returnCentsTest2() { // The seventh test sees a user insert an acceptable coin amount but not make a purchase or even a selection. So we are checking that the correct amount of unspent cents is given back to the user
		VendingMachine iVend = new VendingMachine(10,10,10);
		iVend.insertCents(105);
		assertEquals(iVend.returnUnspentCents(),105);
	}
	@Test()
	public void profitTest() { // The final test sees a user insert an acceptable coin amount and also make a an acceptable selection and then proceed to make an acceptable purchase on all three available treats. So we are checking that the correct amount of profit has been reported from the users purchase
		VendingMachine iVend = new VendingMachine(10,10,10);
		iVend.insertCents(100);
		iVend.makeSelection(0);
		iVend.purchaseSelection();
		iVend.insertCents(115);
		iVend.makeSelection(1);
		iVend.purchaseSelection();
		iVend.insertCents(130);
		iVend.makeSelection(2);
		iVend.purchaseSelection();
		assertEquals(iVend.getProfits(),345);
	}
}